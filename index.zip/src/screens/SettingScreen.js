import React from 'react';
import { View, Text } from 'react-native';

const CreditScreen = () => (
  <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
    <Text>Credit Screen</Text>
  </View>
);

export default CreditScreen;
