const imageMap = {
  'sharonburger.png': require('../../assets/sharonburger.png'),
  'sharonprofile.png': require('../../assets/sharonprofile.png'),
  'zim.png': require('../../assets/zimflag.png'),
  'sharonburger2.png': require('../../assets/sharonburger2.png'), // adjust path if needed
  // Add more mappings as you add more images
};

export default imageMap;
